"""
机械臂自动抓取螺丝刀脚本 (基于 scenes/xunjian_arm_scene.xml + models/xunjian_arm.xml)。

流程: 在绿色目标区随机摆放螺丝刀 -> 等待自然下落静止 -> 读取螺丝刀真实位姿(仿真状态,无需感知)
      -> 用雅可比阻尼最小二乘法做逆运动学 -> 预抓取 -> 竖直下降 -> 闭合夹爪
      -> 抬起 -> 平移到收纳盒(plasticbox)上方 -> 张开夹爪把螺丝刀放入盒中 -> 退回。

说明:
  * 每次运行螺丝刀在绿色区域 (zone_target) 的可达子范围内随机位置+随机朝向, 抓取逻辑自动适配。
  * 收纳盒中心离机械臂底座较远, 竖直向下的姿态够不到; 搬运/放置阶段让夹爪朝收纳盒方向
    倾斜约 45°, 并先在盒口高处悬停再竖直下放, 避免手里的螺丝刀扫到盒壁把盒子撞飞。

运行:
    conda activate xunjian_vla_workspace
    python scripts/auto_grasp_screwdriver.py              # 随机种子(每次不同)
    python scripts/auto_grasp_screwdriver.py --seed 7     # 固定种子(可复现)
"""

import argparse
import time
from pathlib import Path

import mujoco
import mujoco.viewer
import numpy as np

SCRIPT_DIR = Path(__file__).resolve().parent
SCENE_PATH = SCRIPT_DIR / ".." / "scenes" / "xunjian_arm_scene.xml"

ARM_JOINTS = ["joint1", "joint2", "joint3", "joint4", "joint5", "joint6"]
ARM_ACTUATORS = ["Joint1", "Joint2", "Joint3", "Joint4", "Joint5", "Joint6"]
EE_SITE = "ee_site"

OBJECT_BODY = "real_screwdriver"
OBJECT_FREEJOINT = "fj_screwdriver"  # 螺丝刀的自由关节 (7 维: 3 位置 + 4 四元数)
STORAGE_BOX_BODY = "plasticbox"  # 收纳盒 (放置目标)

# 螺丝刀随机初始摆放范围 (世界坐标, 位于绿色目标区 zone_target 内且机械臂可达的子范围)。
# 绿色区整体 x∈[0.30,0.60] y∈[-0.125,0.125], 但只有近端 (x≲0.44) 各朝向都能稳定抓取,
# 故随机采样限制在下面这个可达子范围; 朝向 (绕竖直轴 yaw) 完全随机。
SPAWN_X_RANGE = (0.35, 0.44)
SPAWN_Y_RANGE = (-0.09, 0.09)
SPAWN_DROP_Z = 0.80  # 随机位置的初始下落高度, 让它落到桌面自然静止

# 机械臂底座在世界系下的大致水平位置 (link0 附近), 用于算"朝盒子方向倾斜"的朝向
BASE_XY = np.array([0.13, 0.0])
# 搬运/放置阶段夹爪相对竖直方向朝收纳盒倾斜的角度; 盒子较远, 倾斜可把工作空间伸过去
RELEASE_TILT_DEG = 45.0
# 松开夹爪时末端相对盒壁顶部的高度余量; 取较小值让螺丝刀贴近盒口再释放, 直落盒底不挂在盒壁上
RELEASE_CLEARANCE = 0.028
# 搬运时先在盒口正上方这个高度悬停(相对盒壁顶部), 再竖直下降进盒;
# 关键: 直接斜插进盒会让手里的螺丝刀扫到盒壁, 把整个收纳盒撞飞。先高位越过盒壁再竖直下放可避免。
# 取得足够高: 有些握法(螺丝刀把手重、垂得低)需要更高的悬停才能让工具整体越过盒壁不刮蹭。
HOVER_CLEARANCE = 0.16

# 夹爪开合 (joint8, joint9), 对应 ctrlrange [-0.02, 0.02]
GRIP_OPEN = (-0.02, 0.02)
GRIP_CLOSE = (0.02, -0.02)

# 抬升/平移时相对物体表面的安全高度候选(从大到小尝试,取第一个逆解收敛的)
LIFT_CLEARANCES = (0.05, 0.04, 0.03, 0.025, 0.02, 0.015, 0.01)
# 预抓取悬停在物体正上方的高度; 之后从这里竖直下降到物体, 保证下降是干净的直线不推歪物体
PREGRASP_HEIGHT = 0.08

# 需要隐藏显示、但保留模型定义的海绵相关几何体
SPONGE_GEOMS = ["sponge_geom", "sponge_axis_x", "sponge_axis_y", "sponge_axis_z"]

# 各阶段仿真步数 (timestep=0.001s)
STEPS_SETTLE = 1500
STEPS_PREGRASP = 800
STEPS_DESCEND = 600
STEPS_GRIP_HOLD = 600
STEPS_LIFT = 600
STEPS_TRANSPORT = 900
STEPS_BOX_DESCEND = 500
STEPS_RELEASE_HOLD = 600
STEPS_RETREAT = 600
STEPS_FINAL_SETTLE = 1500  # 放手后让螺丝刀在盒中彻底落定(也用于后台试跑评估结果)

Q_HOME = np.zeros(6)

# 多组预设种子, 逆解陷入局部极小值/关节限位时用于重新搜索
IK_SEED_BANK = [
    np.array([0.0, -0.5, 0.5, 0.0, -1.0, 2.3]),
    np.zeros(6),
    np.array([0.0, -0.8, 0.0, 0.0, -1.5, 2.3]),
    np.array([0.0, -1.2, 0.8, 0.0, 0.5, 4.0]),
    np.array([0.3, -1.0, 1.0, 0.3, -1.0, 3.0]),
]


class ArmIK:
    """基于 mj_jacSite 的阻尼最小二乘逆运动学 (只解 joint1..joint6, 6 自由度对应位置+姿态)。"""

    def __init__(self, model):
        self.model = model
        self.qpos_adr = np.array([model.joint(j).qposadr[0] for j in ARM_JOINTS])
        self.dof_adr = np.array([model.joint(j).dofadr[0] for j in ARM_JOINTS])
        self.jnt_range = np.array([model.joint(j).range for j in ARM_JOINTS])
        self.site_id = model.site(EE_SITE).id
        self._scratch = mujoco.MjData(model)

    def _forward(self, d):
        mujoco.mj_kinematics(self.model, d)
        mujoco.mj_comPos(self.model, d)

    def solve(self, base_qpos, q_seed, target_pos, target_mat,
              max_iter=400, tol=1e-4, damping=0.05, step=0.5):
        d = self._scratch
        d.qpos[:] = base_qpos
        d.qpos[self.qpos_adr] = q_seed

        target_quat = np.zeros(4)
        mujoco.mju_mat2Quat(target_quat, target_mat.flatten())
        jacp = np.zeros((3, self.model.nv))
        jacr = np.zeros((3, self.model.nv))
        pos_err = np.zeros(3)
        rot_err = np.zeros(3)

        for _ in range(max_iter):
            self._forward(d)
            cur_pos = d.site_xpos[self.site_id]
            cur_mat = d.site_xmat[self.site_id].reshape(3, 3)
            cur_quat = np.zeros(4)
            mujoco.mju_mat2Quat(cur_quat, cur_mat.flatten())

            pos_err = target_pos - cur_pos
            rot_err = _quat_err_to_rotvec(_quat_mul(target_quat, _quat_conj(cur_quat)))
            err = np.concatenate([pos_err, rot_err])
            if np.linalg.norm(pos_err) < tol and np.linalg.norm(rot_err) < tol * 5:
                break

            mujoco.mj_jacSite(self.model, d, jacp, jacr, self.site_id)
            J = np.vstack([jacp[:, self.dof_adr], jacr[:, self.dof_adr]])
            JJt = J @ J.T + (damping ** 2) * np.eye(6)
            dq = J.T @ np.linalg.solve(JJt, err)
            new_q = np.clip(d.qpos[self.qpos_adr] + step * dq,
                             self.jnt_range[:, 0], self.jnt_range[:, 1])
            d.qpos[self.qpos_adr] = new_q

        return d.qpos[self.qpos_adr].copy(), np.linalg.norm(pos_err), np.linalg.norm(rot_err)

    def solve_multi_seed(self, base_qpos, seeds, target_pos, target_mat, tol=2e-3):
        best = None
        for seed in seeds:
            qsol, perr, rerr = self.solve(base_qpos, seed, target_pos, target_mat)
            score = perr + 0.05 * rerr
            if best is None or score < best[3]:
                best = (qsol, perr, rerr, score)
            if perr < tol and rerr < tol * 10:
                return qsol, perr, rerr
        return best[0], best[1], best[2]

    def solve_above(self, base_qpos, q_seed, xy, base_z, target_mat,
                     clearances=LIFT_CLEARANCES, tol=2e-3, multi_seed=False):
        """在 xy 上方尝试若干安全高度, 返回第一个收敛的逆解(找不到就返回误差最小的)。"""
        seeds = [q_seed] + IK_SEED_BANK if multi_seed else [q_seed]
        best = None
        for clearance in clearances:
            target = np.array([xy[0], xy[1], base_z + clearance])
            qsol, perr, rerr = self.solve_multi_seed(base_qpos, seeds, target, target_mat, tol=tol)
            if perr < tol and rerr < tol * 10:
                return qsol, clearance
            if best is None or perr < best[2]:
                best = (qsol, clearance, perr)
        return best[0], best[1]


def _quat_conj(q):
    return np.array([q[0], -q[1], -q[2], -q[3]])


def _quat_mul(q1, q2):
    w1, x1, y1, z1 = q1
    w2, x2, y2, z2 = q2
    return np.array([
        w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
        w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
        w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
        w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2,
    ])


def _quat_err_to_rotvec(qe):
    w = np.clip(qe[0], -1.0, 1.0)
    angle = 2.0 * np.arccos(w)
    s = np.sqrt(max(1.0 - w * w, 1e-12))
    if s < 1e-8:
        return np.zeros(3)
    if angle > np.pi:
        angle -= 2 * np.pi
    return qe[1:] / s * angle


def mat_from_approach(x_hint, z_approach):
    """由(水平参考轴, 接近轴)构造末端姿态旋转矩阵, 自动正交化。"""
    x = x_hint / np.linalg.norm(x_hint)
    z = z_approach / np.linalg.norm(z_approach)
    y = np.cross(z, x)
    y /= np.linalg.norm(y)
    x = np.cross(y, z)
    return np.column_stack([x, y, z])


def mat_tilted_toward(tilt_deg, lean_dir):
    """构造一个"整体朝下、但向 lean_dir 水平方向倾斜 tilt_deg"的末端姿态。

    tilt_deg=0 即竖直向下; 增大后夹爪接近轴向 lean_dir 方向外伸, 用来够到较远的目标。
    """
    theta = np.radians(tilt_deg)
    yd = lean_dir / np.linalg.norm(lean_dir)
    z_approach = np.array([np.sin(theta) * yd[0], np.sin(theta) * yd[1], -np.cos(theta)])
    x_hint = np.array([yd[1], -yd[0], 0.0])  # 与倾斜方向正交的水平轴
    return mat_from_approach(x_hint, z_approach)


def hide_geoms(model, names):
    """只把 rgba 的透明度置 0, 不改动/删除任何 XML 中的模型定义, 物理碰撞仍然生效。"""
    for name in names:
        gid = model.geom(name).id
        model.geom_rgba[gid][3] = 0.0


def randomize_object_pose(model, data, rng):
    """在绿色目标区可达子范围内, 给螺丝刀设置随机位置 + 随机水平朝向(绕竖直轴)。

    直接写自由关节 fj_screwdriver 的 qpos, 不改动 XML 模型定义; 之后靠仿真自然落到桌面。
    返回 (x, y, yaw) 便于打印。
    """
    adr = model.joint(OBJECT_FREEJOINT).qposadr[0]
    x = rng.uniform(*SPAWN_X_RANGE)
    y = rng.uniform(*SPAWN_Y_RANGE)
    yaw = rng.uniform(-np.pi, np.pi)
    data.qpos[adr:adr + 3] = [x, y, SPAWN_DROP_Z]
    data.qpos[adr + 3:adr + 7] = [np.cos(yaw / 2), 0.0, 0.0, np.sin(yaw / 2)]  # 绕 z 轴旋转的四元数
    return x, y, yaw


def grasp_plan_for(ik, base_qpos, obj_xy, obj_z, sign_dir):
    """给定一个刀杆朝向 sign_dir, 求抓取位姿。

    夹爪竖直向下, X 轴(末端红色 x 轴)与 sign_dir 同向; 手指闭合方向与刀杆垂直(卡住杆身)。
    预抓取位姿在物体正上方 PREGRASP_HEIGHT 处, 且用抓取解做种子, 保证两者同一关节构型 ——
    这样下降是干净的竖直线, 不会横扫把螺丝刀推离手指。
    返回 dict(R, q_pre, q_grasp, perr, gripX)。
    """
    R = mat_from_approach(sign_dir, np.array([0.0, 0.0, -1.0]))
    q_grasp, perr, _ = ik.solve_multi_seed(
        base_qpos, IK_SEED_BANK, np.array([obj_xy[0], obj_xy[1], obj_z]), R, tol=1e-3)
    q_pre, _, _ = ik.solve_multi_seed(
        base_qpos, [q_grasp], np.array([obj_xy[0], obj_xy[1], obj_z + PREGRASP_HEIGHT]), R, tol=2e-3)
    return dict(R=R, q_pre=q_pre, q_grasp=q_grasp, perr=perr, gripX=R[:, 0].copy())


def pick_and_place(model, data, viewer, arm_act_ids, j8_id, j9_id, ik, plan,
                   verbose=True, realtime=True):
    """执行完整的抓取->放入收纳盒->退回流程。real run 与规划试跑共用同一套逻辑, 保证一致。

    data 需处于"物体已落定、机械臂在 Q_HOME"的状态。plan 来自 grasp_plan_for。
    返回 dict(final_pos, box_moved, in_box); 查看器被关闭则返回 None。
    """
    body_id = model.body(OBJECT_BODY).id
    box_bid = model.body(STORAGE_BOX_BODY).id
    R_grasp = plan["R"]
    q_cur = data.qpos[ik.qpos_adr].copy()
    box_xy0 = data.xpos[box_bid][:2].copy()

    def log(msg):
        if verbose:
            print(msg)

    def move(q_from, q_to, grip, n):
        return run_motion(model, data, viewer, arm_act_ids, j8_id, j9_id,
                          q_from, q_to, grip, n, realtime=realtime)

    def hold(q_hold, grip, n):
        return hold_pose(model, data, viewer, arm_act_ids, j8_id, j9_id,
                         q_hold, grip, n, realtime=realtime)

    log("[2/8] 预抓取位姿 ...")
    if not move(q_cur, plan["q_pre"], GRIP_OPEN, STEPS_PREGRASP):
        return None
    q_cur = plan["q_pre"]

    log("[3/8] 竖直下降贴近螺丝刀 ...")
    # 悬停到位后重新读取物体当前 xy(消除落定微小漂移), 用同一构型做种子, 保证竖直下降
    obj_now = data.xpos[body_id].copy()
    q_grasp, _, _ = ik.solve_multi_seed(
        data.qpos, [plan["q_grasp"], plan["q_pre"]],
        np.array([obj_now[0], obj_now[1], obj_now[2]]), R_grasp, tol=1e-3)
    if not move(q_cur, q_grasp, GRIP_OPEN, STEPS_DESCEND):
        return None
    q_cur = q_grasp

    log("[4/8] 闭合夹爪抓取 ...")
    if not hold(q_cur, GRIP_CLOSE, STEPS_GRIP_HOLD):
        return None

    grasp_xy = data.xpos[body_id][:2].copy()
    grasp_z = data.xpos[body_id][2]
    log("[5/8] 抬起 ...")
    q_lift, _ = ik.solve_above(data.qpos, q_cur, grasp_xy, grasp_z, R_grasp, multi_seed=True)
    if not move(q_cur, q_lift, GRIP_CLOSE, STEPS_LIFT):
        return None
    q_cur = q_lift

    # 收纳盒世界坐标与盒口高度, 直接从模型读, 不写死数字
    box_pos = data.xpos[box_bid].copy()
    box_xy = box_pos[:2].copy()
    box_wall_top = box_pos[2] + 0.06  # 盒壁顶部 (盒壁 geom 高 0.03, 中心在 +0.03)
    hover_z = box_wall_top + HOVER_CLEARANCE
    release_z = box_wall_top + RELEASE_CLEARANCE
    R_release = mat_tilted_toward(RELEASE_TILT_DEG, box_xy - BASE_XY)

    log("[6/8] 先移动到收纳盒正上方高处悬停 (避免手里的螺丝刀扫到盒壁) ...")
    q_hover, _, _ = ik.solve_multi_seed(
        data.qpos, [q_cur] + IK_SEED_BANK,
        np.array([box_xy[0], box_xy[1], hover_z]), R_release, tol=6e-3)
    if not move(q_cur, q_hover, GRIP_CLOSE, STEPS_TRANSPORT):
        return None
    q_cur = q_hover

    log("[7/8] 竖直下降到盒口, 松开夹爪把螺丝刀放入收纳盒 ...")
    q_release, _, _ = ik.solve_multi_seed(
        data.qpos, [q_cur] + IK_SEED_BANK,
        np.array([box_xy[0], box_xy[1], release_z]), R_release, tol=6e-3)
    if not move(q_cur, q_release, GRIP_CLOSE, STEPS_BOX_DESCEND):
        return None
    q_cur = q_release
    if not hold(q_cur, GRIP_OPEN, STEPS_RELEASE_HOLD):
        return None

    log("[8/8] 退回初始位姿 ...")
    q_retreat, _ = ik.solve_above(data.qpos, q_cur, box_xy, box_wall_top, R_release,
                                  clearances=(0.15, 0.12, 0.10, 0.08), multi_seed=True)
    if not move(q_cur, q_retreat, GRIP_OPEN, STEPS_RETREAT):
        return None
    if not move(q_retreat, Q_HOME, GRIP_OPEN, STEPS_RETREAT):
        return None
    if not hold(Q_HOME, GRIP_OPEN, STEPS_FINAL_SETTLE):  # 让螺丝刀在盒中彻底落定
        return None

    final_pos = data.xpos[body_id].copy()
    box_moved = float(np.linalg.norm(data.xpos[box_bid][:2] - box_xy0))
    in_box = (abs(final_pos[0] - box_pos[0]) < 0.096 and
              abs(final_pos[1] - box_pos[1]) < 0.148 and
              final_pos[2] < box_wall_top)
    return dict(final_pos=final_pos, box_moved=box_moved, in_box=in_box)


def _hold_dry_run_ok(model, data, arm_act_ids, j8_id, j9_id, ik, plan):
    """在后台无渲染完整"试跑"一遍某个握法的抓取->放盒流程, 判断是否可靠。

    用 mjSTATE_INTEGRATION 完整拷贝物理状态(含求解器热启动量), 保证试跑与真实运行逐帧一致 ——
    个别握法处于"擦着盒壁""夹得勉强"的临界, 只有完整状态拷贝才能可靠预测真实结果。
    返回 True 当且仅当: 抓稳、放进盒里、且没碰翻盒子。
    """
    spec = mujoco.mjtState.mjSTATE_INTEGRATION
    state = np.zeros(mujoco.mj_stateSize(model, spec))
    mujoco.mj_getState(model, data, state, spec)
    scratch = mujoco.MjData(model)
    mujoco.mj_setState(model, scratch, state, spec)
    mujoco.mj_forward(model, scratch)
    dry = pick_and_place(model, scratch, None, arm_act_ids, j8_id, j9_id, ik, plan,
                         verbose=False, realtime=False)
    return dry is not None and dry["box_moved"] < 0.02 and dry["in_box"]


def choose_grasp_orientation(model, data, arm_act_ids, j8_id, j9_id, ik, grasp_xy, grasp_z, shaft_dir):
    """选择下抓时夹爪(末端红色 x 轴)的朝向。

    夹爪 X 轴既可以与刀杆(螺丝刀 y 轴)平行, 也可以垂直 —— 两种都能抓, 于是共有 4 个候选方向
    (±平行、±垂直, 互成 90°)。第一要求: 让红色 x 轴朝前(+X 世界分量为正, 偏左前/右前都行,
    只要不朝后)。因此按"朝前程度"(与 +X 的点积)从大到小逐个尝试, 用物理试跑校验能否抓稳并放进
    盒子, 取第一个既朝前又可行的握法。若朝前的都不可行(极少数落点), 才退而用一个可行但不朝前的。
    返回 (plan, 描述文字)。
    """
    perp = np.array([-shaft_dir[1], shaft_dir[0], 0.0])  # 刀杆水平垂直方向
    candidates = [shaft_dir, -shaft_dir, perp, -perp]
    candidates.sort(key=lambda d: float(d[0]), reverse=True)  # 越朝前(+X)越靠前

    first_reachable = None
    non_forward_ok = None
    for xdir in candidates:
        plan = grasp_plan_for(ik, data.qpos, grasp_xy, grasp_z, xdir)
        if plan["perr"] >= 3e-3:
            continue  # 这个朝向够不到(腕关节顶死), 跳过
        if first_reachable is None:
            first_reachable = plan
        rel = "平行" if abs(float(np.dot(xdir, shaft_dir))) > 0.7 else "垂直"
        is_forward = xdir[0] > 0.02
        print(f"    后台试跑候选握法: 红X≈[{xdir[0]:+.2f},{xdir[1]:+.2f}] ({rel}刀杆, "
              f"{'朝前' if is_forward else '非朝前'}) ...")
        if _hold_dry_run_ok(model, data, arm_act_ids, j8_id, j9_id, ik, plan):
            if is_forward:
                return plan, f"红X朝前(前向分量{xdir[0]:+.2f}, {rel}刀杆)"
            # 排序后非朝前的只会越来越靠后, 记下这个"最不朝后"的可行解即可停
            non_forward_ok = (plan, f"红X未能朝前(前向分量{xdir[0]:+.2f}, {rel}刀杆; 朝前握法均不可行)")
            break

    if non_forward_ok is not None:
        return non_forward_ok
    if first_reachable is not None:
        return first_reachable, "兜底(候选均未通过试跑, 取最朝前且够得到的握法)"
    return grasp_plan_for(ik, data.qpos, grasp_xy, grasp_z, shaft_dir), "兜底(退化)"


def set_ctrl(data, arm_act_ids, j8_id, j9_id, arm_q, grip):
    data.ctrl[arm_act_ids] = arm_q
    data.ctrl[j8_id] = grip[0]
    data.ctrl[j9_id] = grip[1]


def run_motion(model, data, viewer, arm_act_ids, j8_id, j9_id,
                q_start, q_end, grip, n_steps, realtime=True):
    """用余弦缓动从 q_start 插值到 q_end, 同时驱动夹爪到目标开合。"""
    for i in range(1, n_steps + 1):
        t0 = time.time()
        alpha = i / n_steps
        alpha_smooth = 0.5 - 0.5 * np.cos(np.pi * alpha)
        q = q_start + (q_end - q_start) * alpha_smooth
        set_ctrl(data, arm_act_ids, j8_id, j9_id, q, grip)
        mujoco.mj_step(model, data)
        if viewer is not None:
            if not viewer.is_running():
                return False
            viewer.sync()
        if realtime:
            dt = model.opt.timestep - (time.time() - t0)
            if dt > 0:
                time.sleep(dt)
    return True


def hold_pose(model, data, viewer, arm_act_ids, j8_id, j9_id, q_hold, grip, n_steps, realtime=True):
    return run_motion(model, data, viewer, arm_act_ids, j8_id, j9_id,
                       q_hold, q_hold, grip, n_steps, realtime=realtime)


def main(seed=None):
    model = mujoco.MjModel.from_xml_path(str(SCENE_PATH))
    data = mujoco.MjData(model)
    mujoco.mj_resetData(model, data)

    hide_geoms(model, SPONGE_GEOMS)

    arm_act_ids = np.array([model.actuator(a).id for a in ARM_ACTUATORS])
    j8_id = model.actuator("Joint8").id
    j9_id = model.actuator("Joint9").id
    ik = ArmIK(model)

    # 随机摆放螺丝刀 (绿色区可达子范围内, 随机位置 + 随机朝向)
    rng = np.random.default_rng(seed)
    data.qpos[ik.qpos_adr] = Q_HOME
    sx, sy, syaw = randomize_object_pose(model, data, rng)
    mujoco.mj_forward(model, data)
    print(f"[随机初始化] 种子={seed}, 螺丝刀落点 x={sx:.3f} y={sy:.3f} yaw={np.degrees(syaw):.0f}deg")

    with mujoco.viewer.launch_passive(model, data) as viewer:
        print("[1/8] 等待场景物体自然下落静止 ...")
        if not hold_pose(model, data, viewer, arm_act_ids, j8_id, j9_id, Q_HOME, GRIP_OPEN, STEPS_SETTLE):
            return

        body_id = model.body(OBJECT_BODY).id
        obj_pos = data.xpos[body_id].copy()
        obj_mat = data.xmat[body_id].reshape(3, 3).copy()

        # 螺丝刀网格长轴在物体局部坐标系是 Y 轴, 用它算出刀杆在世界系下的水平朝向
        shaft_dir = obj_mat @ np.array([0.0, 1.0, 0.0])
        shaft_dir[2] = 0.0
        if np.linalg.norm(shaft_dir) < 1e-3:
            shaft_dir = np.array([1.0, 0.0, 0.0])  # 螺丝刀立起来的极端情况, 退化为默认方向
        shaft_dir /= np.linalg.norm(shaft_dir)

        grasp_xy = obj_pos[:2].copy()
        grasp_z = obj_pos[2]
        print(f"    螺丝刀静止位置: {obj_pos}, 刀杆朝向(水平投影): {shaft_dir}")

        # 在刀杆 180° 对称的两个抓取朝向里择优(优先红色x轴朝前, 但保证不撞飞盒子)
        plan, choice_desc = choose_grasp_orientation(
            model, data, arm_act_ids, j8_id, j9_id, ik, grasp_xy, grasp_z, shaft_dir)
        print(f"    抓取朝向: {choice_desc}, 末端红X轴世界方向≈{np.round(plan['gripX'], 2)}, "
              f"逆解 pos_err={plan['perr']:.2e}")

        # 执行完整抓取->放盒->退回 (与后台试跑同一套逻辑)
        result = pick_and_place(model, data, viewer, arm_act_ids, j8_id, j9_id, ik, plan,
                                verbose=True, realtime=True)
        if result is None:
            return
        print(f"完成。螺丝刀最终位置: {result['final_pos']}, 盒子位移: {result['box_moved']:.3f} m, "
              f"是否落入收纳盒: {'是' if result['in_box'] else '否'}")

        print("抓取流程结束, 保持窗口运行, 关闭查看器窗口以退出 ...")
        while viewer.is_running():
            t0 = time.time()
            mujoco.mj_step(model, data)
            viewer.sync()
            dt = model.opt.timestep - (time.time() - t0)
            if dt > 0:
                time.sleep(dt)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="机械臂抓取绿色区随机摆放的螺丝刀并放入收纳盒")
    parser.add_argument("--seed", type=int, default=None,
                        help="随机种子; 不指定则每次运行螺丝刀落点/朝向都不同")
    args = parser.parse_args()
    main(seed=args.seed)
